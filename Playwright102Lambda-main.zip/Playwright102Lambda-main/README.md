# Playwright102Lambda
test_scenario_1[web_name0] : QAL9D-YKF6J-P01AU-KJFRC
test_scenario_1[web_name1] : 3T3UK-1FPZC-S2H75-JCEJB 
test_scenario_2[web_name0] : VBNGK-O0UHF-WSWVI-BT8LG
test_scenario_2[web_name1] : E145H-NPJ6M-KVKRB-YRQGE
test_scenario_3[web_name0] : SD6GA-DQJS0-D9VC9-ZSDJG
test_scenario_3[web_name1] : L7T8Y-JBEJL-MKIWE-NQDXP


test_scenario_2[web_name1] : IMWKP-JHPG3-A29GC-O8BVC
test_scenario_3[web_name1] : 70HFT-XKRJV-ESY6C-QCNUM
test_scenario_1[web_name1] : WTE38-KEJ0F-BEYBJ-ANTXC
test_scenario_3[web_name0] : T3D3A-QGALC-QKLWL-NNOWN
test_scenario_1[web_name0] : I744C-DRUYH-HTNP9-YODVZ
test_scenario_2[web_name0] : GFZCM-JAVBX-D6QVX-T9HSJ
